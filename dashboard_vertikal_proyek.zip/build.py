#!/usr/bin/env python3
"""Gabungkan proyek menjadi satu file mandiri (offline): python3 build.py -> dashboard_vertikal.html
Chart.js dan font tetap dimuat dari CDN."""
import re, json, base64, pathlib
r = pathlib.Path(__file__).parent
rd = lambda p: (r/p).read_text(encoding='utf-8')
html = rd('index.html')
logo = 'data:image/webp;base64,' + base64.b64encode((r/'assets/logo.webp').read_bytes()).decode()
html = html.replace('assets/logo.webp', logo)
css = rd('css/app.css')
for n in ('bg.webp','bg-m.webp'):
    css = css.replace('../assets/'+n, 'data:image/webp;base64,' + base64.b64encode((r/('assets/'+n)).read_bytes()).decode())
html = html.replace('<link rel="stylesheet" href="css/app.css">', '<style>\n' + css + '\n</style>')
html = html.replace(' defer></script>\n</head>', '></script>\n</head>')          # Chart.js dimuat sebelum skrip inline
js = '\n'.join(rd(f'js/{n}.js') for n in ['config','data','analysis','charts','panels','table','filters','app'])
data = json.dumps(json.loads(rd('data/data.json')), ensure_ascii=False, separators=(',',':')).replace('</', '<\\/')
html = re.sub(r'<script src="js/[a-z]+\.js" defer></script>\n?', '', html)
html = html.replace('</body>', '<script>window.__DATA__=' + data + ';</script>\n<script>\n' + js + '\n</script>\n</body>')
out = r/'dashboard_vertikal.html'; out.write_text(html, encoding='utf-8'); print(out, out.stat().st_size, 'bytes')
