# Dashboard Pemetaan Karakter VERTIKAL — SMAN 1 Gunung Talang

- `dashboard_vertikal.html` : versi mandiri (satu file, bisa dibuka langsung/offline).
- `index.html` + `css/` `js/` `data/` `assets/` : versi terpisah untuk deployment. Jalankan lewat server (mis. `python3 -m http.server`), bukan file://.
- Ganti data: edit `data/data.json`, lalu `python3 build.py` untuk membuat ulang versi mandiri.

## Format data
`rows`: `[timestamp, nama, tingkat, ruang, pengisian, jawaban(14 digit 1-4), student_id (opsional)]`
- Jika `student_id` diisi, itu jadi identitas utama. Jika kosong, identitas = tingkat + nama yang sudah dinormalisasi; variasi ejaan yang aman digabung otomatis.
- `aliases`: pemetaan manual `{"NAMA SALAH":"NAMA BENAR"}` untuk pasangan nama mirip yang tidak digabung otomatis.
- Duplikat: satu siswa × satu pengisian = satu respons (yang terbaru).
