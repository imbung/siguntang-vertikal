/* Siswa prioritas: tabel di desktop, kartu di HP. Identitas = id siswa, bukan sekadar nama. */
const pill = v => isNaN(v) ? '–' : `<span class="pl ${cat(v).c}">${f2(v)}</span> <small class="cl">${cat(v).t}</small>`;
const dlt = x => isNaN(x.dl) ? '–' : (x.dl>0?'+':'')+f2(x.dl);
const dcl = x => isNaN(x.dl) ? '' : (x.dl<0 ? 'neg' : 'pos');
let TR = [];

function buildStudents(R,S){
  const cg = grp(R.cur), bg = R.G;
  TR = [...cg].map(([id,r]) => {
    const b = bg.get(id)||r, ps=[...new Set(b.map(x=>x.p))].sort(), a=idx(b.filter(x=>x.p===ps[0])), z=idx(b.filter(x=>x.p===ps[ps.length-1])), h=hs(r), l=h.indexOf(Math.min(...h.filter(x=>!isNaN(x))));
    return {id, n:r[r.length-1].nm, k:r[r.length-1].rm, c:r.length, v:idx(r), dl:ps.length>1?z-a:NaN, h:H[l]?H[l].n:'–'};
  });
  const key = S.sort==='low' ? (x=>x.v) : (x=>isNaN(x.dl)?9:x.dl);
  TR.sort((a,b)=>key(a)-key(b));
  const q = S.q.trim().toUpperCase();
  TR.L = TR.filter(x=>x.n.includes(q));
  return TR;
}

function renderStudents(S){
  const L = TR.L, N = 40;
  $('tbs').textContent = L.length+' siswa · '+(S.sort==='low'?'diurut dari skor terendah':'diurut dari penurunan terbesar');
  $('st').innerHTML = '<caption class="vh">Daftar siswa prioritas</caption><tr><th scope="col">Nama</th><th scope="col">Kelas</th><th scope="col">Pengisian</th><th scope="col">Skor rata-rata</th><th scope="col">Delta (awal → akhir)</th><th scope="col">Kebiasaan terendah</th></tr>' +
    L.slice(0,N).map(x=>`<tr><th scope="row">${x.n}</th><td>${x.k}</td><td>${x.c}</td><td>${pill(x.v)}</td><td class="${dcl(x)}">${dlt(x)}</td><td>${x.h}</td></tr>`).join('') +
    (L.length>N?`<tr><td colspan="6" class="sub">Menampilkan ${N} teratas. Ekspor CSV memuat semua ${L.length} siswa.</td></tr>`:'');
  $('stc').innerHTML = L.slice(0,N).map(x=>`<article class="sk"><header><b>${x.n}</b><span>${x.k}</span></header>
    <dl><div><dt>Skor</dt><dd>${pill(x.v)}</dd></div><div><dt>Delta</dt><dd class="${dcl(x)}">${dlt(x)}</dd></div><div><dt>Pengisian</dt><dd>${x.c}×</dd></div></dl>
    <p><small>Kebiasaan terendah</small><br><b>${x.h}</b></p></article>`).join('') +
    (L.length>N?`<p class="sub">Menampilkan ${N} teratas dari ${L.length} siswa. Gunakan pencarian atau ekspor CSV.</p>`:'') +
    (!L.length?'<p class="sub">Tidak ada siswa yang cocok.</p>':'');
}

function exportCsv(){
  const e = v => '"'+String(v).replace(/"/g,'""')+'"';
  const rows = [['Nama','Kelas','Jumlah pengisian','Skor rata-rata','Kategori','Delta','Kebiasaan terendah'], ...TR.L.map(x=>[x.n,x.k,x.c,f2(x.v),cat(x.v).t,f2(x.dl),x.h])];
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['\ufeff'+rows.map(r=>r.map(e).join(',')).join('\n')],{type:'text/csv'}));
  a.download = 'siswa_prioritas.csv'; a.click();
}
