/* Konfigurasi: 7 kebiasaan, 14 butir, aksi (terhubung ke butir), kategori skor */
// q pada tiap aksi = indeks butir (0-13) yang paling terkait dengan aksi itu.
const H = [
  {n:'Bangun Pagi', q:[0,1], c:'#1B4FC4', a:[
    {t:'Sepakati jam tidur dan alarm mandiri selama satu minggu', q:[0,1]},
    {t:'Pasang tantangan “bangun tanpa dibangunkan” dengan stiker kehadiran', q:[1]},
    {t:'Mulai kelas wali dengan cek siapa yang sempat bersantai sebelum berangkat', q:[0]}]},
  {n:'Beribadah', q:[2,3], c:'#FF7B50', a:[
    {t:'Ingatkan jadwal ibadah wajib lewat pengingat harian kelas', q:[2]},
    {t:'Biasakan doa bersama sebelum pelajaran dimulai', q:[3]},
    {t:'Libatkan guru agama untuk refleksi singkat tiap pekan', q:[2,3]}]},
  {n:'Berolahraga', q:[4,5], c:'#2ED8A7', a:[
    {t:'Jadwalkan 15 menit gerak berkeringat tiap pagi atau jeda pelajaran', q:[4]},
    {t:'Ajak kelas peregangan 2 menit di sela jam belajar panjang', q:[5]},
    {t:'Buat tantangan olahraga antar kelompok dalam kelas', q:[4]}]},
  {n:'Makan Sehat & Bergizi', q:[6,7], c:'#F5C518', a:[
    {t:'Kampanyekan sarapan sebelum berangkat dan bekal sayur atau buah', q:[6,7]},
    {t:'Adakan pekan “piring sehat” dengan foto menu siswa', q:[6]},
    {t:'Bagikan contoh menu murah dan bergizi ke orang tua', q:[6,7]}]},
  {n:'Gemar Belajar', q:[8,9], c:'#3E8EF7', a:[
    {t:'Sisihkan 10 menit mengulang materi di rumah selain PR', q:[8]},
    {t:'Buat jadwal baca bebas dan pojok baca kelas', q:[9]},
    {t:'Minta siswa berbagi satu bacaan menarik setiap minggu', q:[9]}]},
  {n:'Bermasyarakat', q:[10,11], c:'#E255A1', a:[
    {t:'Beri tugas piket rumah mingguan yang dicatat dalam jurnal', q:[10]},
    {t:'Terapkan “satu jam tanpa gadget bersama keluarga” tiap malam', q:[11]},
    {t:'Bentuk teman sejawat yang saling membantu di kelas', q:[10]}]},
  {n:'Tidur Cepat', q:[12,13], c:'#38A3F5', a:[
    {t:'Tetapkan batas gadget satu jam sebelum tidur', q:[12]},
    {t:'Ajak siswa mencatat jam tidur selama satu minggu', q:[12]},
    {t:'Edukasikan manfaat tidur sebelum 22.30 kepada siswa dan orang tua', q:[12,13]}]}
];
const QL = ['Bangun awal','Bangun mandiri','Ibadah tepat waktu','Berdoa','Olahraga ≥15 menit','Peregangan','Sayur / buah','Sarapan','Mengulang pelajaran','Baca di luar buku wajib','Bantu tugas rumah / teman','Ngobrol keluarga tanpa gadget','Tidur < 22.30','Badan segar saat bangun'];
const QH = []; H.forEach((h,i) => h.q.forEach(q => QH[q] = i));
const LB = ['Selalu','Sering','Jarang','Tidak Pernah'];

// Kategori skor (satu sumber kebenaran untuk KPI, tabel, kartu, heatmap, insight)
function cat(v){
  if (isNaN(v)) return {t:'–', c:'', k:''};
  if (v >= 3.5) return {t:'Sangat baik', c:'g', k:'sb'};
  if (v >= 3)   return {t:'Baik', c:'g', k:'b'};
  if (v >= 2.5) return {t:'Cukup', c:'a', k:'c'};
  return {t:'Perlu perhatian', c:'r', k:'pp'};
}
