/* Aplikasi: muat data, render, navigasi tampilan, tema, splash kunjungan pertama */
const VIEWS = ['ringkasan','analisis','siswa','rekomendasi'];
let LR = null, INFO = null, RV = 0;
const drawn = {};
const curView = () => { const v = location.hash.slice(1); return VIEWS.includes(v) ? v : 'ringkasan'; };
const reduced = () => matchMedia('(prefers-reduced-motion: reduce)').matches;

function render(){
  LR = analyze(D,S);
  buildStudents(LR,S);
  const M = renderHeatmap(D,S);
  RV++; const v = curView(); renderCharts(LR,S,v); drawn[v] = RV;   // hanya grafik di tab aktif
  renderKpis(LR); countUp(); renderFocus(LR); renderRecs(LR);
  renderStudents(S);
  renderInsights(LR,M,TR);
  $('fcnt').textContent = activeFilterCount() ? activeFilterCount()+' filter aktif' : '';
}
function renderTable(){ if(!LR) return; buildStudents(LR,S); renderStudents(S); }

function showView(first){
  let v = location.hash.slice(1); if (!VIEWS.includes(v)) v = 'ringkasan';
  VIEWS.forEach(x => $('v-'+x).hidden = x!==v);
  document.querySelectorAll('#nav a').forEach(a => { const on = a.getAttribute('href')==='#'+v; a.classList.toggle('on',on); on ? a.setAttribute('aria-current','page') : a.removeAttribute('aria-current'); });
  if (LR && drawn[v]!==RV){ renderCharts(LR,S,v); drawn[v] = RV; }   // tab lain digambar saat pertama dibuka
  requestAnimationFrame(resizeCharts);
  if (!first) window.scrollTo(0,0);
}

async function loadPayload(){
  if (window.__DATA__) return window.__DATA__;       // versi mandiri (offline)
  const r = await fetch('data/data.json');
  if (!r.ok) throw new Error('HTTP '+r.status);
  return r.json();
}

async function init(){
  try {
    const payload = await loadPayload(), out = buildData(payload);
    D = out.D; INFO = out.info;
  } catch(e) {
    $('err').hidden = false;
    $('err').innerHTML = '<b>Data tidak bisa dimuat.</b> Jika dashboard dibuka langsung dari file (file://), browser memblokir pembacaan data.json. Jalankan server lokal (<code>python -m http.server</code> di folder ini) atau pakai versi mandiri <code>dashboard_vertikal.html</code>.';
    return;
  }
  const d = INFO.latest ? new Date(INFO.latest+'T00:00:00') : null;
  $('upd').textContent = d ? 'Data terbaru ' + d.getFullYear() : '';
  $('chips').innerHTML = `<span>${D.length.toLocaleString('id')} respons</span><span>${INFO.students.toLocaleString('id')} siswa</span>`;
  fillT(); bindFilters(render, renderTable);
  render(); showView(true); setupReveal();
}

// Muncul saat di-scroll: satu observer, tiap kartu cukup sekali (unobserve setelah tampil)
function setupReveal(){
  if (reduced() || !('IntersectionObserver' in window)) return;
  const io = new IntersectionObserver(es => es.forEach(e => { if (!e.isIntersecting) return; const el=e.target; el.classList.add('in'); io.unobserve(el); el.addEventListener('transitionend',()=>{el.style.transitionDelay='';},{once:true}); }), {threshold:.06});
  document.querySelectorAll('.g12>.card').forEach((el,i) => { el.classList.add('rv'); el.style.transitionDelay = (i%2)*70+'ms'; io.observe(el); });
}

/* Tema */
const eff = () => document.documentElement.dataset.theme || (matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');
const syncTheme = () => document.querySelectorAll('#th button').forEach(b => { const on=b.dataset.t===eff(); b.classList.toggle('on',on); b.setAttribute('aria-pressed',on); });
document.querySelectorAll('#th button').forEach(b => b.onclick = () => {
  document.documentElement.dataset.theme = b.dataset.t;
  try { localStorage.setItem('th',b.dataset.t); } catch(e){}
  syncTheme(); if (D.length) render();
});
try { const t = localStorage.getItem('th'); if (t) document.documentElement.dataset.theme = t; } catch(e){}
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { syncTheme(); if (D.length) render(); });
syncTheme();

$('ex').onclick = exportCsv;
addEventListener('hashchange', () => showView(false));

/* Splash masuk tiap dibuka (~2 dtk); animasi halaman mulai saat splash memudar (body.go) */
(function(){
  const sp = $('splash'), go = () => { document.body.classList.add('go'); if (D.length) countUp(); };
  if (reduced()) { sp.remove(); go(); return; }
  sp.hidden = false;
  setTimeout(go, 1300);
  setTimeout(() => sp.classList.add('out'), 1500);
  setTimeout(() => sp.remove(), 2200);
})();

init();
