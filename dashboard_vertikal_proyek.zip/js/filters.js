/* Filter: tingkat, ruang, pengisian (utama) + opsi lanjutan (kohort, mode grafik, urutan) */
const S = {t:'Semua', r:'Semua', p:'Semua', rad:false, coh:false, sort:'low', q:''};
let D = [];

function fillT(){
  const ts = ['Semua', ...[...new Set(D.map(r=>r.k))].sort(nat)];
  $('ft').innerHTML = ts.map(x=>`<option>${x}</option>`).join(''); $('ft').value = S.t; fillR();
}
function fillR(){
  const rs = ['Semua', ...[...new Set(D.filter(r=>S.t==='Semua'||r.k===S.t).map(r=>r.rm))].sort(nat)];
  if (!rs.includes(S.r)) S.r = 'Semua';
  $('fr').innerHTML = rs.map(x=>`<option>${x}</option>`).join(''); $('fr').value = S.r;
}
function syncToggles(){
  document.querySelectorAll('[data-k]').forEach(b=>{
    const on = String(S[b.dataset.k]) === b.dataset.v;
    b.classList.toggle('on',on); b.setAttribute('aria-pressed',on);
  });
}
function activeFilterCount(){ return (S.t!=='Semua')+(S.r!=='Semua')+(S.p!=='Semua'); }

function bindFilters(onFull, onTable){
  $('ft').onchange = e => { S.t=e.target.value; fillR(); onFull(); };
  $('fr').onchange = e => { S.r=e.target.value; onFull(); };
  $('fp').onchange = e => { S.p=e.target.value; onFull(); };
  $('reset').onclick = () => { S.t=S.r=S.p='Semua'; $('fp').value='Semua'; fillT(); onFull(); };
  $('q').oninput = e => { S.q=e.target.value; onTable(); };
  document.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>{
    const v = b.dataset.v==='true' ? true : b.dataset.v==='false' ? false : b.dataset.v;
    S[b.dataset.k] = v; syncToggles();
    (b.dataset.k==='sort') ? onTable() : onFull();
  });
  syncToggles();
}
