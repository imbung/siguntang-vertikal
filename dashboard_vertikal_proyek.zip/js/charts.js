/* Grafik (Chart.js) dan heatmap. Setiap grafik punya ringkasan teks untuk pembaca layar. */
const $ = id => document.getElementById(id);
const css = v => getComputedStyle(document.documentElement).getPropertyValue(v).trim();
const CH = {};
function mk(id,cfg){ if(CH[id]) CH[id].destroy(); CH[id] = new Chart($(id),cfg); }
const resizeCharts = () => Object.values(CH).forEach(c => c.resize());

function chartDefaults(){
  const d = Chart.defaults;
  d.color = css('--mu'); d.borderColor = css('--bd');
  d.font.family = "'Plus Jakarta Sans',system-ui,sans-serif";
  d.animation = {duration: 600, easing:'easeOutQuart'};
  d.plugins.legend.position = 'bottom'; d.plugins.legend.labels.usePointStyle = true; d.plugins.legend.labels.boxWidth = 7;
  d.elements.bar.borderRadius = 6; d.scale.grid.borderDash = [4,4]; d.scale.border.display = false;
}

function renderCharts(R,S,v){
  chartDefaults();
  const {cur, base, H1, Q, jp, scopeShort} = R, cc = ['--sel','--ser','--jar','--tp'].map(css);
  if (v==='analisis') {

  // 1. Kebiasaan: bar / radar
  mk('c1', S.rad
    ? {type:'radar', data:{labels:H.map(h=>h.n), datasets:[{label:'Skor', data:H1, borderColor:css('--ac'), backgroundColor:css('--ac')+'33'}]}, options:{maintainAspectRatio:false, plugins:{legend:{display:false}}, scales:{r:{min:1,max:4,ticks:{backdropColor:'transparent'}}}}}
    : {type:'bar', data:{labels:H.map(h=>h.n), datasets:[{data:H1, backgroundColor:H.map(h=>h.c)}]}, options:{maintainAspectRatio:false, plugins:{legend:{display:false}}, scales:{y:{min:1,max:4}}}});
  $('d-c1').textContent = 'Skor rata-rata per kebiasaan: ' + H.map((h,i)=>`${h.n} ${f2(H1[i])}`).join('; ') + '.';

  // 2. Frekuensi jawaban
  const dist = H.map(h => { const v=cur.flatMap(r=>h.q.map(i=>r.a[i])).filter(x=>x>0); return [4,3,2,1].map(s=>v.length?v.filter(x=>x===s).length/v.length*100:0); });
  mk('c2', {type:'bar', data:{labels:H.map(h=>h.n), datasets:LB.map((l,j)=>({label:l, data:dist.map(r=>r[j]), backgroundColor:cc[j]}))},
    options:{indexAxis:'y', maintainAspectRatio:false, scales:{x:{stacked:true,max:100,ticks:{callback:v=>v+'%'}}, y:{stacked:true}}, plugins:{tooltip:{callbacks:{label:c=>c.dataset.label+': '+c.parsed.x.toFixed(1)+'%'}}}}});
  $('d-c2').textContent = 'Persentase jawaban Selalu dan Jarang + Tidak Pernah per kebiasaan: ' + H.map((h,i)=>`${h.n} ${Math.round(dist[i][0])}% dan ${Math.round(dist[i][2]+dist[i][3])}%`).join('; ') + '.';

  }
  if (v==='ringkasan') {
  // 3. Doughnut proporsi
  const ct = [4,3,2,1].map(x=>cur.reduce((n,r)=>n+r.a.filter(y=>y===x).length,0)), tt = ct.reduce((a,b)=>a+b,0)||1;
  mk('c5', {type:'doughnut', data:{labels:LB, datasets:[{data:ct, backgroundColor:cc, borderWidth:0, borderRadius:8, spacing:2}]}, options:{maintainAspectRatio:false, cutout:'74%', plugins:{legend:{display:false}}}});
  $('dc').textContent = f2(R.idx);
  $('dl').innerHTML = LB.map((l,i)=>`<div><i style="background:${cc[i]}"></i><b>${l}</b><small>${ct[i].toLocaleString('id')} · ${(ct[i]/tt*100).toFixed(1).replace('.',',')}%</small></div>`).join('');
  $('d-c5').textContent = 'Proporsi jawaban: ' + LB.map((l,i)=>`${l} ${(ct[i]/tt*100).toFixed(1).replace('.',',')}%`).join('; ') + '.';

  }
  if (v==='analisis') {
  // 4. Peringkat butir
  const ord = QL.map((_,i)=>i).sort((a,b)=>(Q[b]||0)-(Q[a]||0));
  mk('c3', {type:'bar', data:{labels:ord.map(i=>`Q${i+1} ${QL[i]} · ${isNaN(jp[i])?'–':pc(jp[i])} J+TP`), datasets:[{data:ord.map(i=>Q[i]), backgroundColor:ord.map(i=>H[QH[i]].c)}]},
    options:{indexAxis:'y', maintainAspectRatio:false, plugins:{legend:{display:false}, tooltip:{callbacks:{label:c=>'Skor '+f2(c.parsed.x)+' · '+H[QH[ord[c.dataIndex]]].n}}}, scales:{x:{min:1,max:4}, y:{ticks:{font:{size:11}}}}}});
  const top = ord.slice(0,3), bot = ord.slice(-3).reverse();
  $('d-c3').textContent = 'Tiga butir tertinggi: ' + top.map(i=>`${QL[i]} ${f2(Q[i])}`).join('; ') + '. Tiga butir terendah: ' + bot.map(i=>`${QL[i]} ${f2(Q[i])}`).join('; ') + '.';

  }
  if (v==='ringkasan') {
  // 5. Tren pengisian
  const cn = new Set(R.co.map(x=>x[0])), tr = S.coh ? base.filter(r=>cn.has(r.id)) : base, tp = [1,2,3,4].map(p=>tr.filter(r=>r.p===p));
  $('trs').textContent = S.coh ? `Kohort: ${R.co.length} siswa yang mengisi pengisian ke-1 dan ke-4 (${scopeShort})` : `Semua data pada filter tingkat dan ruang (${scopeShort})`;
  mk('c4', {type:'line', data:{labels:['Ke-1','Ke-2','Ke-3','Ke-4'], datasets:[...H.map((h,i)=>({label:h.n, data:tp.map(r=>hs(r)[i]), borderColor:h.c, backgroundColor:h.c, tension:.4, borderWidth:1.5, pointRadius:3})), {label:'Indeks', data:tp.map(idx), borderColor:css('--ink'), backgroundColor:css('--ink'), borderWidth:3, borderDash:[6,4]}]},
    options:{maintainAspectRatio:false, scales:{y:{min:1.5,max:4}}, plugins:{legend:{position:'top',align:'end',labels:{boxWidth:7,font:{size:11}}}}}});
  const iv = tp.map((r,i)=>({p:i+1,v:idx(r)})).filter(x=>!isNaN(x.v));
  $('d-c4').textContent = iv.length>1 ? `Skor indeks ${iv[iv.length-1].v>=iv[0].v?'naik':'turun'} dari ${f2(iv[0].v)} pada pengisian ke-${iv[0].p} menjadi ${f2(iv[iv.length-1].v)} pada pengisian ke-${iv[iv.length-1].p}. Per pengisian: ${iv.map(x=>`ke-${x.p} ${f2(x.v)}`).join('; ')}.` : 'Data belum cukup untuk melihat perkembangan.';
  }
}

// Heatmap: warna + teks kategori (tidak hanya bergantung pada warna)
function renderHeatmap(A,S){
  const hm = A.filter(r=>(S.t==='Semua'||r.k===S.t) && (S.p==='Semua'||r.p===+S.p));
  const rm = [...new Set(hm.map(r=>r.rm))].sort(nat);
  const M = rm.map(k=>{ const rr=hm.filter(r=>r.rm===k); return {k, n:rr.length, h:hs(rr), i:idx(rr)}; });
  const fl = M.flatMap(m=>m.h).filter(x=>!isNaN(x)), mn = Math.min(...fl), mx = Math.max(...fl);
  const bg = v => { if(isNaN(v)) return ''; const t=(v-mn)/((mx-mn)||1); return t<.5 ? `rgba(255,123,80,${((1-2*t)*.55).toFixed(2)})` : `rgba(46,200,160,${((2*t-1)*.55).toFixed(2)})`; };
  $('hm').innerHTML = '<caption class="vh">Skor rata-rata tiap kebiasaan per ruang kelas</caption><tr><th scope="col">Ruang</th>'+H.map(h=>`<th scope="col">${h.n}</th>`).join('')+'<th scope="col">Indeks</th><th scope="col">n</th></tr>' +
    M.map(m=>{ const l=m.h.indexOf(Math.min(...m.h.filter(x=>!isNaN(x))));
      return `<tr><th scope="row"><b>${m.k}</b></th>` + m.h.map((v,i)=>`<td style="background:${bg(v)}">${f2(v)}${i===l?' ◂':''}<small class="cl">${cat(v).t}</small></td>`).join('') + `<td><b>${f2(m.i)}</b><small class="cl">${cat(m.i).t}</small></td><td>${m.n}</td></tr>`; }).join('');
  return M;
}
