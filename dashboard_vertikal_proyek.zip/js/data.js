/* Lapisan data: normalisasi, identitas siswa, penggabungan nama mirip, deduplikasi.
   Format baris: [timestamp, nama, tingkat, ruang, pengisian, jawaban(14 digit), student_id?]
   Jika student_id tersedia, ia dipakai sebagai identitas utama (nama hanya untuk tampilan). */
const normName = n => String(n||'').trim().replace(/\s+/g,' ').toUpperCase();
const skel = n => n.replace(/[^A-Z]/g,'').replace(/(.)\1+/g,'$1'); // abaikan spasi & huruf dobel
function lev(a,b){
  let p = Array.from({length:b.length+1},(_,i)=>i);
  for (let i=1;i<=a.length;i++){
    const c=[i];
    for (let j=1;j<=b.length;j++) c.push(Math.min(p[j]+1,c[j-1]+1,p[j-1]+(a[i-1]!==b[j-1]?1:0)));
    p=c;
  }
  return p[b.length];
}

function buildData(payload){
  const aliases = {};
  Object.entries(payload.aliases||{}).forEach(([a,b]) => aliases[normName(a)] = normName(b));
  const info = {rawRows:(payload.rows||[]).length, invalid:0, dupRemoved:0, merged:[], suspects:[]};

  // 1. parse
  let R = [];
  (payload.rows||[]).forEach((r,i) => {
    const k = String(r[2]||'').trim().toUpperCase(), ru0 = String(r[3]||'').trim().toUpperCase();
    const ru = k==='X' ? ru0.replace(/^F/,'E') : ru0.replace(/^E/,'F'); // ruang E hanya kelas X
    let nm = normName(r[1]); nm = aliases[nm] || nm;
    const a = String(r[5]||'').split('').map(Number);
    if (!nm || !(+r[4] > 0) || !a.some(x => x>0)) { info.invalid++; return; }
    R.push({ts:String(r[0]), nm, sid:r[6]?String(r[6]).trim():'', k, rm:(k+' '+ru).trim(), p:+r[4], a, i});
  });

  // 2. gabungkan variasi nama (hanya bila tidak ada student_id), per tingkat
  const byK = new Map();
  R.filter(r => !r.sid).forEach(r => { if(!byK.has(r.k)) byK.set(r.k,new Map()); const m=byK.get(r.k); if(!m.has(r.nm)) m.set(r.nm,{nm:r.nm,n:0,rooms:new Set(),ps:new Set()}); const v=m.get(r.nm); v.n++; v.rooms.add(r.rm); v.ps.add(r.p); });
  const canon = new Map(); // "k|nama" -> nama kanonik
  byK.forEach((m,k) => {
    const V=[...m.values()], par=V.map((_,i)=>i), f=i=>par[i]===i?i:(par[i]=f(par[i]));
    for (let i=0;i<V.length;i++) for (let j=i+1;j<V.length;j++){
      const a=V[i], b=V[j], d=lev(skel(a.nm),skel(b.nm));
      const shareRoom=[...a.rooms].some(x=>b.rooms.has(x)), overlapP=[...a.ps].some(x=>b.ps.has(x));
      if (d===0 || (d===1 && shareRoom && !overlapP)) par[f(j)]=f(i);          // aman digabung
      else if (d<=2 && Math.min(a.nm.length,b.nm.length)>=8) info.suspects.push([k,a.nm,b.nm]); // perlu dicek manual
    }
    const grp=new Map(); V.forEach((v,i)=>{const g=f(i); if(!grp.has(g)) grp.set(g,[]); grp.get(g).push(v)});
    grp.forEach(vs => {
      const best=vs.slice().sort((x,y)=>y.n-x.n||y.nm.length-x.nm.length)[0];
      vs.forEach(v => { canon.set(k+'|'+v.nm,best.nm); if(v.nm!==best.nm) info.merged.push([v.nm,best.nm,k]); });
    });
  });
  // saran manual yang sebenarnya sudah tergabung tidak perlu ditampilkan
  info.suspects = info.suspects.filter(([k,a,b]) => canon.get(k+'|'+a)!==canon.get(k+'|'+b));

  // 3. identitas + deduplikasi: satu siswa × satu pengisian = satu respons (yang terbaru)
  const best = new Map();
  R.forEach(r => {
    r.nm = canon.get(r.k+'|'+r.nm) || r.nm;
    r.id = r.sid || (r.k+'|'+r.nm);
    const key = r.id+'|'+r.p, o = best.get(key);
    if (!o) best.set(key,r);
    else { info.dupRemoved++; if (r.ts >= o.ts) best.set(key,r); }
  });
  const D = [...best.values()].sort((x,y)=>x.i-y.i);
  const dates = D.map(r=>r.ts.slice(0,10)).sort();
  info.latest = dates[dates.length-1] || '';
  info.students = new Set(D.map(r=>r.id)).size;
  return {D, info};
}
