/* Analisis: statistik, tren antar pengisian, rekomendasi berbasis butir, insight */
const avg = a => { a=a.filter(x=>x>0); return a.length ? a.reduce((s,x)=>s+x,0)/a.length : NaN; };
const f2 = v => isNaN(v) ? '–' : v.toFixed(2).replace('.',',');
const pc = v => Math.round(v*100)+'%';
const nat = (a,b) => a.localeCompare(b,'id',{numeric:true});
const hs  = rows => H.map(h => avg(rows.flatMap(r => h.q.map(i => r.a[i]))));
const qs  = rows => QL.map((_,i) => avg(rows.map(r => r.a[i])));
const idx = rows => avg(rows.flatMap(r => r.a));
function grp(rows){ const m=new Map(); rows.forEach(r=>{ if(!m.has(r.id)) m.set(r.id,[]); m.get(r.id).push(r); }); return m; }

// Aksi diurutkan: yang terkait butir terlemah tampil lebih dulu
function actionsFor(dim, weakQ){
  const A = H[dim].a.map(a => ({...a, hit: a.q.includes(weakQ)}));
  return A.sort((x,y) => (y.hit-x.hit));
}

function analyze(A, S){
  const base = A.filter(r => (S.t==='Semua'||r.k===S.t) && (S.r==='Semua'||r.rm===S.r));
  const cur  = base.filter(r => S.p==='Semua' || r.p===+S.p);
  const R = {base, cur};
  R.H1 = hs(cur); R.Q = qs(cur); R.G = grp(base);
  R.ok = R.H1.map((v,i)=>isNaN(v)?null:i).filter(i=>i!==null);
  R.hi = R.ok.reduce((a,b)=>R.H1[b]>R.H1[a]?b:a, R.ok[0]);
  R.lo = R.ok.reduce((a,b)=>R.H1[b]<R.H1[a]?b:a, R.ok[0]);
  R.jp = QL.map((_,i)=>{ const v=cur.map(r=>r.a[i]).filter(x=>x>0); return v.length ? v.filter(x=>x<=2).length/v.length : NaN; });
  R.scope = (S.t==='Semua'?'Semua tingkat':'Kelas '+S.t)+(S.r!=='Semua'?' · '+S.r:'')+' · Pengisian '+S.p;
  R.scopeShort = R.scope.split(' · Pengisian')[0];
  R.idx = idx(cur);
  R.bp = [1,2,3,4].map(p => base.filter(r => r.p===p));

  // Kohort (mengisi ke-1 dan ke-4)
  R.co = [...R.G].filter(([,r]) => r.some(x=>x.p===1) && r.some(x=>x.p===4));
  R.d = R.co.length ? avg(R.co.map(([,r])=>idx(r.filter(x=>x.p===4)))) - avg(R.co.map(([,r])=>idx(r.filter(x=>x.p===1)))) : NaN;

  // Tren indeks: dibanding pengisian sebelumnya
  const pv = R.bp.map((r,i)=>({p:i+1,v:idx(r)})).filter(x=>!isNaN(x.v));
  let to = S.p==='Semua' ? pv[pv.length-1] : pv.find(x=>x.p===+S.p);
  let from = to ? pv.filter(x=>x.p<to.p).pop() : null;
  R.trend = to && from ? {from:from.p, to:to.p, d:to.v-from.v} : null;

  // Butir terlemah pada kebiasaan terendah -> aksi yang terkait butir itu
  if (R.ok.length){
    R.weakQ = H[R.lo].q.slice().sort((a,b)=>R.Q[a]-R.Q[b])[0];
    R.acts = actionsFor(R.lo, R.weakQ);
    R.low2 = R.ok.slice().sort((a,b)=>R.H1[a]-R.H1[b]).slice(0,2).map(i=>{
      const wq = H[i].q.slice().sort((a,b)=>R.Q[a]-R.Q[b])[0];
      return {i, wq, acts:actionsFor(i,wq)};
    });
  }
  return R;
}

// Insight: dikembalikan sebagai {main:[3 pertama], more:[sisanya], concl}
function insights(R, M, TR){
  const {cur, scope, H1, Q, jp, hi, lo, co, d} = R, ns = new Set(cur.map(r=>r.id)).size, I = [];
  const qw = jp.reduce((a,v,i)=>v>(jp[a]||0)?i:a,0), qb = Q.reduce((a,v,i)=>v>Q[a]?i:a,0), c = cat(R.idx);
  I.push(['Capaian umum',`Indeks karakter ${scope} adalah <b>${f2(R.idx)}</b> dari 4,00, kategori <b>${c.t.toLowerCase()}</b>, berdasarkan ${cur.length.toLocaleString('id')} respons dari ${ns.toLocaleString('id')} siswa.`]);
  I.push(['Kekuatan dan titik lemah',`<b>${H[hi].n}</b> paling kuat (${f2(H1[hi])}), sedangkan <b>${H[lo].n}</b> paling lemah (${f2(H1[lo])}). Selisihnya ${f2(H1[hi]-H1[lo])} poin.`]);
  I.push(['Butir yang perlu perhatian',`<b>Q${qw+1} ${QL[qw]}</b> paling jarang dilakukan: ${pc(jp[qw])} siswa menjawab Jarang atau Tidak Pernah. Butir terkuat adalah Q${qb+1} ${QL[qb]} (skor ${f2(Q[qb])}).`]);
  I.push(['Perkembangan antar pengisian', co.length ? `Pada kohort ${co.length} siswa yang mengisi ke-1 dan ke-4, skor indeks <b>${Math.abs(d)<.05?'relatif stabil':(d>0?'naik ':'turun ')+f2(Math.abs(d))+' poin'}</b> (selisih ${d>0?'+':''}${f2(d)}).` : 'Belum ada siswa dengan pengisian ke-1 dan ke-4 pada filter ini, sehingga perkembangan belum bisa dihitung.']);
  const MM = M.filter(m=>m.n>=10).sort((a,b)=>b.i-a.i);
  if (MM.length>1){ const bt=MM[0], w=MM[MM.length-1], wi=w.h.indexOf(Math.min(...w.h.filter(x=>!isNaN(x))));
    I.push(['Perbandingan ruang kelas',`Ruang <b>${bt.k}</b> memiliki indeks tertinggi (${f2(bt.i)}) dan <b>${w.k}</b> terendah (${f2(w.i)}). Ruang ${w.k} paling perlu pendampingan pada ${H[wi].n}.`]);
  } else I.push(['Perbandingan ruang kelas','Data ruang kelas belum cukup untuk dibandingkan pada filter ini.']);
  const lw = TR.filter(x=>x.v<2.5).length, dr = TR.filter(x=>x.dl<-.2).length;
  I.push(['Siswa prioritas',`<b>${lw}</b> siswa memiliki skor rata-rata di bawah 2,50 dan <b>${dr}</b> siswa mengalami penurunan lebih dari 0,20 poin. Mereka layak didahulukan untuk pendampingan.`]);
  const a0 = R.acts[0].t;
  const concl = `Karakter siswa pada ${scope} berada pada kategori ${c.t.toLowerCase()}. Fokus perbaikan utama adalah <b style="color:#fff">${H[lo].n}</b>, terutama butir Q${R.weakQ+1} ${QL[R.weakQ]}. Langkah awal yang disarankan: ${a0[0].toLowerCase()+a0.slice(1)}.`;
  return {I, concl};
}
