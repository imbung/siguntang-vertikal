/* Panel non-grafik: KPI, rekomendasi, insight, kartu fokus */
const KI = ['▤','☺','◎','▲','▼','⇅'];
const KC = [['#DCE8FF','#1B4FC4','#1B4FC4'],['#DDFBF2','#1FBF93','#2ED8A7'],['#FFE9E1','#FF7B50','#FF7B50'],['#1B4FC4','#fff','#1B4FC4'],['#FFF4CC','#C79A00','#F5C518'],['#E1EEFF','#3E8EF7','#3E8EF7']];

function spark(ser,c){
  const v = ser.filter(x=>!isNaN(x)); if (v.length<2) return '';
  const mn=Math.min(...v), mx=Math.max(...v), w=84, h=34;
  const P = v.map((x,i)=>[i*w/(v.length-1), h-4-(x-mn)/((mx-mn)||1)*(h-10)]);
  let d = 'M'+P[0]; for (let i=1;i<P.length;i++){ const m=(P[i][0]+P[i-1][0])/2; d+=`C${m},${P[i-1][1]} ${m},${P[i][1]} ${P[i][0]},${P[i][1]}`; }
  return `<svg class="spk" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" aria-hidden="true"><path d="${d}" fill="none" stroke="${c}" stroke-width="2" stroke-linecap="round"/></svg>`;
}

function renderKpis(R){
  const {cur, base, bp, H1, ok, hi, lo, co, d, scope, trend} = R;
  let i = 0;
  const K = (t,v,s,ser,extra='') => { const k=i++, c=KC[k];
    return `<div class="card kpi" style="--i:${k}"><div class="ki" style="background:${c[0]};color:${c[1]}" aria-hidden="true">${KI[k]}</div><b>${v}</b><span>${t}</span>${extra}<small>${s||''}</small>${spark(ser,c[2])}</div>`; };
  const c = cat(R.idx);
  const tr = trend
    ? `<em class="tr ${Math.abs(trend.d)<.05?'':(trend.d>0?'pos':'neg')}">${Math.abs(trend.d)<.05?'→ stabil':(trend.d>0?'↑ naik ':'↓ turun ')+f2(Math.abs(trend.d))} dari pengisian ke-${trend.from}</em>` : '';
  const pill = isNaN(R.idx) ? '' : `<em class="pl ${c.c}">${c.t}</em>`;
  $('kpis').innerHTML =
    K('Total respons aktif', cur.length.toLocaleString('id'), 'dari '+base.length.toLocaleString('id')+' respons pada filter tingkat/ruang', bp.map(r=>r.length)) +
    K('Siswa unik', new Set(cur.map(r=>r.id)).size.toLocaleString('id'), scope, bp.map(r=>new Set(r.map(x=>x.id)).size)) +
    K('Rata-rata skor indeks', f2(R.idx)+' '+pill, 'skala 1,00–4,00', bp.map(idx), tr) +
    K('Kebiasaan tertinggi', ok.length?H[hi].n:'–', ok.length?'skor '+f2(H1[hi])+' · '+cat(H1[hi]).t:'', bp.map(r=>hs(r)[hi])) +
    K('Kebiasaan terendah', ok.length?H[lo].n:'–', ok.length?'skor '+f2(H1[lo])+' · '+cat(H1[lo]).t:'', bp.map(r=>hs(r)[lo])) +
    K('Delta skor kohort (ke-1 → ke-4)', isNaN(d)?'–':`<span class="${d<0?'neg':'pos'}" style="font:inherit;color:inherit;margin:0">${d>0?'+':''}${f2(d)}</span>`, 'kohort '+co.length+' siswa', bp.map(idx));
}

function renderFocus(R){
  $('foc').innerHTML = R.ok.length
    ? `<h3>Fokus aksi</h3><p>${H[R.lo].n} paling rendah (${f2(R.H1[R.lo])}) pada ${R.scope}.</p><a href="#rekomendasi">Lihat rekomendasi</a>` : '';
}

// Rekomendasi: kebiasaan terendah -> butir terlemah -> aksi yang terkait butir itu
function renderRecs(R){
  $('recs').textContent = 'Berdasarkan kebiasaan terendah, butir terlemah, lalu aksi yang menyasar butir itu pada ' + R.scope;
  $('rec').innerHTML = R.low2 && R.low2.length ? R.low2.map(({i,wq,acts})=>
    `<div class="rec"><b>${H[i].n}</b> · skor ${f2(R.H1[i])} <span class="pl ${cat(R.H1[i]).c}">${cat(R.H1[i]).t}</span>
     <div class="sub" style="margin:4px 0">Butir terlemah: Q${wq+1} ${QL[wq]} (${isNaN(R.jp[wq])?'–':pc(R.jp[wq])} menjawab Jarang atau Tidak Pernah)</div>
     <ul>${acts.map(a=>`<li>${a.t}${a.hit?' <span class="tag">tepat sasaran</span>':''}</li>`).join('')}</ul></div>`).join('')
    : '<p class="sub">Belum ada data pada filter ini.</p>';
}

function renderInsights(R,M,TR){
  if (!R.cur.length){ $('ins2').innerHTML = '<p class="sub">Belum ada data pada filter ini.</p>'; return; }
  const {I, concl} = insights(R,M,TR);
  const card = ([t,x],i) => `<div class="ins"><div class="ki" style="background:${KC[i][0]};color:${KC[i][1]}" aria-hidden="true">${KI[i]}</div><div><h3>${t}</h3><p>${x}</p></div></div>`;
  $('ins2').innerHTML = I.map(card).join('') + `<div class="concl"><b>Kesimpulan</b><p>${concl}</p></div>`;
}

// Hitung naik angka KPI: satu loop rAF untuk semua angka, hanya node teks (tanpa reflow berat)
function countUp(){
  if (matchMedia('(prefers-reduced-motion: reduce)').matches || !document.body.classList.contains('go')) return;
  const items = [];
  document.querySelectorAll('.kpi b').forEach(b => {
    const tn = b.firstChild; if (!tn || tn.nodeType!==3) return;
    const t = tn.data.trim(); if (!/^[\d.,]+$/.test(t)) return;
    items.push({tn, final:tn.data, dec:t.includes(',')?t.split(',')[1].length:0, n:parseFloat(t.replace(/\./g,'').replace(',','.')), sp:/\s$/.test(tn.data)?' ':''});
  });
  if (!items.length) return;
  const t0 = performance.now();
  const step = now => {
    const k = Math.min(1,(now-t0)/650), e = 1-Math.pow(1-k,3);
    items.forEach(o => { o.tn.data = k>=1 ? o.final : (o.dec ? (o.n*e).toFixed(o.dec).replace('.',',') : Math.round(o.n*e).toLocaleString('id')) + o.sp; });
    if (k<1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}
